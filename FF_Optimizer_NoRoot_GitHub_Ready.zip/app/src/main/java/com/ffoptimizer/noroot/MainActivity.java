package com.ffoptimizer.noroot;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    TextView report;
    LinearLayout root;
    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(24),dp(20),dp(20)); root.setBackgroundColor(Color.rgb(15,20,32));
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title = new TextView(this); title.setText("FF OPTIMIZER  •  NO ROOT"); title.setTextSize(23); title.setTextColor(Color.WHITE); title.setTypeface(null,1); root.addView(title);
        TextView note = new TextView(this); note.setText("فحص حقيقي داخل Android — بلا Root وبلا Boost وهمي"); note.setTextColor(0xffb7c7dd); note.setTextSize(15); note.setPadding(0,dp(12),0,dp(18)); root.addView(note);
        button("فحص المحاكي / Scan", () -> scan());
        button("فتح Free Fire", () -> launchGame());
        button("إعدادات Android", () -> { try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch(Exception e) { toast("الإعدادات غير متاحة"); } });
        report = new TextView(this); report.setTextColor(Color.WHITE); report.setTextSize(15); report.setTextIsSelectable(true); report.setPadding(0,dp(20),0,0); root.addView(report);
        scan();
    }
    void button(String label, Runnable action) {
        Button btn = new Button(this); btn.setText(label); btn.setAllCaps(false); btn.setOnClickListener(v -> action.run()); root.addView(btn);
    }
    void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    void launchGame() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
        if (i != null) startActivity(i); else toast("Free Fire ما لقيتهاش. ثبت اللعبة أولاً.");
    }
    void scan() {
        ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
        Runtime rt = Runtime.getRuntime();
        float refresh = getWindowManager().getDefaultDisplay().getRefreshRate();
        String s = "ANDROID DIAGNOSTICS\n\n" +
            "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
            "Device: " + Build.MANUFACTURER + " / " + Build.MODEL + "\n" +
            "CPU ABI: " + android.text.TextUtils.join(", ", Build.SUPPORTED_ABIS) + "\n" +
            "Available processors (app): " + rt.availableProcessors() + "\n" +
            String.format(Locale.US,"RAM total: %.2f GB\nRAM available: %.2f GB\n",mi.totalMem/1073741824.0,mi.availMem/1073741824.0) +
            "Low-memory flag: " + (mi.lowMemory ? "YES" : "NO") + "\n" +
            String.format(Locale.US,"Display refresh rate: %.1f Hz\n",refresh) +
            "\nRECOMMENDATIONS\n" +
            "• Free Fire: Smooth graphics, High FPS (if available).\n" +
            "• BlueStacks: test 4 CPU cores, 4GB RAM, 1280x720, high frame rate enabled.\n" +
            "• Close unused apps using the emulator's normal controls.\n" +
            "• Measure real FPS using the emulator's FPS counter.\n" +
            "\nLIMITATIONS\nThis app cannot change Windows GPU/CPU settings, kill other apps, unlock FPS caps or measure Free Fire FPS directly.\n";
        report.setText(s);
    }
}
