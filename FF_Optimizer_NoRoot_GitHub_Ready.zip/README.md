# FF Optimizer No Root — GitHub-ready

A diagnostic tool for Android 9+ emulators with no root and no unrealistic FPS-boost claims. Shows emulator RAM, display refresh rate, CPU ABI and other Android information, with a button to launch Free Fire.

## Build a working APK using GitHub Actions

1. Create a GitHub repository (the default branch should be `main` or `master`).
2. Extract this ZIP. Upload **the contents** of this folder to the repository root, **not the ZIP file**. Make sure `settings.gradle`, `build.gradle`, `app/`, and `.github/workflows/build-apk.yml` are in the repository root.
3. Open the GitHub **Actions** tab. Select **Build Android APK** from the left sidebar. If your workflow is on the default branch, click **Run workflow** > **Run workflow**.
4. Wait for a green successful check. Click the completed run, scroll to **Artifacts**, and download **FF-Optimizer-NoRoot-APK**.
5. Extract the downloaded artifact. Drag `app-debug.apk` onto BlueStacks or MSI App Player to install it.

`on: push` also triggers the build when the files are committed to `main` or `master`.

### If the Actions tab is empty

Check the exact path `.github/workflows/build-apk.yml` at the repository root and the default branch. If actions are disabled, visit **Settings > Actions > General** and allow workflows. If you only uploaded the ZIP file, delete it from the repo and upload its extracted contents.

### Alternative: create the workflow in your existing repository

From the repository, select **Add file > Create new file**. In the filename field enter `.github/workflows/build-apk.yml` and paste the contents of the file with the same name included in this archive. Commit directly to your default branch.

### Compatibility and limitations

The workflow uses JDK 17, Android Gradle Plugin 8.7.3, Gradle 8.9, and Android SDK 35. Debug APKs are signed with the standard debug key and intended for testing. This app cannot change Windows CPU/GPU settings, clean other apps' RAM by force, unlock Free Fire FPS limits or measure the game's actual FPS. It has no root access.

This workspace lacks the Android SDK/Gradle toolchain; the build process has not been run here. GitHub Actions will compile the APK and show the full error log if a step fails.
